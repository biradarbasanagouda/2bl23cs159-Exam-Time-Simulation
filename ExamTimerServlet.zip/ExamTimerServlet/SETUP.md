# Setup & Submission Notes (for Suma)

This file is **for your reference only** — you can delete it before pushing
to GitHub if you like. It contains step-by-step notes for getting the
project running on your laptop.

---

## 1. Eclipse import

1. Open Eclipse for Enterprise Java.
2. **File → New → Dynamic Web Project**, name it `ExamTimerServlet`.
3. When asked for the target runtime, select **Apache Tomcat v10.x**
   (this matters — Tomcat 10 uses `jakarta.servlet.*`, which is what this
   code imports).
4. Set "Dynamic web module version" to **5.0**.
5. Click **Next**, **Next**, and **make sure the "Generate web.xml deployment descriptor" checkbox is ticked** before you click Finish.
6. Once the project is created:
   - Copy `src/com/suma/ExamTimerServlet.java` into `src/com/suma/` in your project.
   - Replace the auto-generated `WebContent/index.html` with the one provided.
   - Replace the auto-generated `WebContent/WEB-INF/web.xml` with the one provided.

If you don't see a `WebContent/` folder but instead see `src/main/webapp/`, just put the files there — Eclipse uses one or the other depending on the project type.

## 2. Running on Tomcat

1. Right-click the project → **Run As → Run on Server**.
2. Pick your Tomcat 10 instance.
3. Eclipse will open a browser tab. If it lands on a 404, just visit
   `http://localhost:8080/ExamTimerServlet/index.html` manually.

## 3. Taking your own screenshots (recommended)

The screenshots in `screenshots/` are mockups that match the actual app
layout — they will look very close to the real thing. **However, the
assignment says screenshots must show your application running in a real
browser**, so once your app is running:

1. Visit `http://localhost:8080/ExamTimerServlet/index.html` and press
   `Win + Shift + S` (Windows) to capture the form. Save as
   `screenshots/screenshot1.png` (overwrite the mockup).
2. Click **Start Exam**, wait ~30 seconds, refresh, then capture the page
   that shows the running timer. Save as `screenshots/screenshot2.png`.
3. Click **End Exam** and capture the summary. Save as
   `screenshots/screenshot3.png`.

The file names already match what's referenced in `README.md`, so
overwriting them is enough — no further edits needed.

## 4. Common mistakes to avoid

- **Wrong Tomcat version.** If you use Tomcat 9 or older, the
  `jakarta.servlet` imports will fail. Either upgrade to Tomcat 10/11, or
  replace every `jakarta.servlet` with `javax.servlet` in the `.java` file
  AND change the namespace in `web.xml` to
  `http://xmlns.jcp.org/xml/ns/javaee` with version `4.0`.
- **Don't upload `.metadata`, `.classpath`, `.project`, `build/`, `target/`,
  or `.settings/` to GitHub.** A simple `.gitignore` is included (see below)
  to help with this.
- **README placeholders.** Already filled in with your name, USN, problem
  number — but double-check before pushing.

## 5. Quick GitHub commands

From inside the project folder, after you've cloned your empty repo:

```bash
git add .
git commit -m "Servlet Assignment - Problem 73 - Suma Biradar"
git branch -M main
git push -u origin main
```

If `git push` asks for a password, use a **Personal Access Token** from
GitHub Settings → Developer Settings → Personal Access Tokens (Classic),
not your GitHub account password.

## 6. Final checklist before submitting the Google Form

- [ ] Project runs on `localhost:8080` without errors
- [ ] `index.html`, `ExamTimerServlet.java`, `web.xml` all visible on GitHub
- [ ] `screenshots/` folder has at least 2 PNGs that show the app in a browser
- [ ] `README.md` shows formatted nicely on GitHub (tables, images render)
- [ ] Repository visibility is set to **Public**
- [ ] Test the GitHub URL in an Incognito window before submitting
